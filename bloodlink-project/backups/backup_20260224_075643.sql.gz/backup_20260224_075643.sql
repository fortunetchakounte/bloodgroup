-- BloodLink Database Backup
-- Generated: 2026-02-24 07:56:43
--

--
-- Structure de la table `admin_logs`
--
CREATE TABLE `admin_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` int(11) DEFAULT NULL,
  `action` varchar(50) DEFAULT NULL,
  `target_type` varchar(20) DEFAULT NULL,
  `target_id` int(11) DEFAULT NULL,
  `details` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_admin_logs_admin` (`admin_id`),
  KEY `idx_admin_logs_target` (`target_type`,`target_id`),
  KEY `idx_admin_logs_date` (`created_at`),
  CONSTRAINT `admin_logs_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `admin_reports`
--
CREATE TABLE `admin_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `report_type` varchar(50) NOT NULL,
  `title` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `file_format` enum('csv','pdf','excel') DEFAULT 'csv',
  `filters` text DEFAULT NULL,
  `generated_by` int(11) NOT NULL,
  `generated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `download_count` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `generated_by` (`generated_by`),
  CONSTRAINT `admin_reports_ibfk_1` FOREIGN KEY (`generated_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `audit_logs`
--
CREATE TABLE `audit_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `hospital_id` int(11) DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `entity_type` varchar(50) DEFAULT NULL,
  `entity_id` int(11) DEFAULT NULL,
  `old_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`old_data`)),
  `new_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`new_data`)),
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_user` (`user_id`),
  KEY `idx_hospital` (`hospital_id`),
  KEY `idx_action` (`action`),
  KEY `idx_created` (`created_at`),
  CONSTRAINT `audit_logs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL,
  CONSTRAINT `audit_logs_ibfk_2` FOREIGN KEY (`hospital_id`) REFERENCES `hospitals` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `badges`
--
CREATE TABLE `badges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `badge_code` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(100) NOT NULL,
  `color` varchar(20) DEFAULT '#6c757d',
  `category` enum('donation','engagement','achievement','special') NOT NULL,
  `requirement_type` enum('donation_count','consecutive_donations','response_time','helped_hospitals','special_event') NOT NULL,
  `requirement_value` int(11) NOT NULL,
  `xp_reward` int(11) DEFAULT 10,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `badge_code` (`badge_code`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `badges`
--
INSERT INTO `badges` VALUES ('1', 'first_donation', 'Premier don', 'Effectuez votre premier don de sang', '?', '#FFD700', 'donation', 'donation_count', '1', '50', '2026-01-24 02:34:58');
INSERT INTO `badges` VALUES ('2', 'bronze_donor', 'Donneur Bronze', '5 dons effectués', '?', '#CD7F32', 'donation', 'donation_count', '5', '100', '2026-01-24 02:34:58');
INSERT INTO `badges` VALUES ('3', 'silver_donor', 'Donneur Argent', '15 dons effectués', '?', '#C0C0C0', 'donation', 'donation_count', '15', '250', '2026-01-24 02:34:58');
INSERT INTO `badges` VALUES ('4', 'gold_donor', 'Donneur Or', '30 dons effectués', '?', '#FFD700', 'donation', 'donation_count', '30', '500', '2026-01-24 02:34:58');
INSERT INTO `badges` VALUES ('5', 'platinum_donor', 'Donneur Platine', '50 dons effectués', '?', '#E5E4E2', 'donation', 'donation_count', '50', '1000', '2026-01-24 02:34:58');
INSERT INTO `badges` VALUES ('6', 'quick_responder', 'Répondeur Rapide', 'Répondez à 10 demandes en moins de 24h', '⚡', '#28a745', 'engagement', '', '10', '150', '2026-01-24 02:34:58');
INSERT INTO `badges` VALUES ('7', 'urgent_hero', 'Héros de l\'urgence', 'Répondez à 5 demandes urgentes', '?', '#dc3545', 'engagement', '', '5', '200', '2026-01-24 02:34:58');
INSERT INTO `badges` VALUES ('8', 'hospital_helper', 'Sauveur d\'hôpitaux', 'Aidez 10 hôpitaux différents', '?', '#007bff', 'engagement', 'helped_hospitals', '10', '300', '2026-01-24 02:34:58');
INSERT INTO `badges` VALUES ('9', 'streak_7', 'Série de 7', '7 dons consécutifs sans interruption', '?', '#ff6b6b', 'achievement', 'consecutive_donations', '7', '350', '2026-01-24 02:34:58');
INSERT INTO `badges` VALUES ('10', 'streak_30', 'Série de 30', '30 dons consécutifs', '?', '#ffd93d', 'achievement', 'consecutive_donations', '30', '1000', '2026-01-24 02:34:58');
INSERT INTO `badges` VALUES ('11', 'rare_blood', 'Sang Rare', 'Donneur de groupe sanguin rare (AB-, B-, etc.)', '?', '#6f42c1', 'special', 'special_event', '1', '500', '2026-01-24 02:34:58');
INSERT INTO `badges` VALUES ('12', 'holiday_donor', 'Donneur des Fêtes', 'Don pendant la période des fêtes', '?', '#28a745', 'special', 'special_event', '1', '200', '2026-01-24 02:34:58');
INSERT INTO `badges` VALUES ('13', 'birthday_donor', 'Don d\'anniversaire', 'Don le jour de votre anniversaire', '?', '#ff6b6b', 'special', 'special_event', '1', '300', '2026-01-24 02:34:58');

--
-- Structure de la table `blood_forecasts`
--
CREATE TABLE `blood_forecasts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_id` int(11) NOT NULL,
  `blood_group_id` int(11) NOT NULL,
  `forecast_date` date NOT NULL,
  `predicted_need` int(11) NOT NULL,
  `confidence_level` enum('low','medium','high') DEFAULT 'medium',
  `based_on_historical` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_forecast` (`hospital_id`,`blood_group_id`,`forecast_date`),
  KEY `blood_group_id` (`blood_group_id`),
  CONSTRAINT `blood_forecasts_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospitals` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blood_forecasts_ibfk_2` FOREIGN KEY (`blood_group_id`) REFERENCES `blood_groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `blood_groups`
--
CREATE TABLE `blood_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(5) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `blood_groups`
--
INSERT INTO `blood_groups` VALUES ('2', 'A-');
INSERT INTO `blood_groups` VALUES ('1', 'A+');
INSERT INTO `blood_groups` VALUES ('6', 'AB-');
INSERT INTO `blood_groups` VALUES ('5', 'AB+');
INSERT INTO `blood_groups` VALUES ('4', 'B-');
INSERT INTO `blood_groups` VALUES ('3', 'B+');
INSERT INTO `blood_groups` VALUES ('8', 'O-');
INSERT INTO `blood_groups` VALUES ('7', 'O+');

--
-- Structure de la table `blood_inventory`
--
CREATE TABLE `blood_inventory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_id` int(11) NOT NULL,
  `blood_group_id` int(11) NOT NULL,
  `current_quantity` int(11) DEFAULT 0,
  `minimum_required` int(11) DEFAULT 5,
  `maximum_capacity` int(11) DEFAULT 50,
  `last_updated` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_donation_date` date DEFAULT NULL,
  `status` enum('critical','low','normal','good','full') DEFAULT 'normal',
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_hospital_blood` (`hospital_id`,`blood_group_id`),
  KEY `blood_group_id` (`blood_group_id`),
  KEY `idx_status` (`status`),
  KEY `idx_last_updated` (`last_updated`),
  CONSTRAINT `blood_inventory_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospitals` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blood_inventory_ibfk_2` FOREIGN KEY (`blood_group_id`) REFERENCES `blood_groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `blood_requests`
--
CREATE TABLE `blood_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_id` int(11) NOT NULL,
  `blood_group_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `urgency` enum('normal','urgent','emergency') DEFAULT 'normal',
  `status` enum('pending','approved','fulfilled','cancelled','expired') DEFAULT 'pending',
  `request_date` date NOT NULL,
  `needed_by` date NOT NULL,
  `fulfilled_date` datetime DEFAULT NULL,
  `patient_name` varchar(100) DEFAULT NULL,
  `patient_age` int(11) DEFAULT NULL,
  `patient_gender` enum('M','F','Other') DEFAULT NULL,
  `reason` text DEFAULT NULL,
  `doctor_name` varchar(100) DEFAULT NULL,
  `doctor_license` varchar(50) DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `approved_by` (`approved_by`),
  KEY `idx_hospital` (`hospital_id`),
  KEY `idx_blood_group` (`blood_group_id`),
  KEY `idx_status` (`status`),
  KEY `idx_urgency` (`urgency`),
  KEY `idx_needed_by` (`needed_by`),
  CONSTRAINT `blood_requests_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospitals` (`id`) ON DELETE CASCADE,
  CONSTRAINT `blood_requests_ibfk_2` FOREIGN KEY (`blood_group_id`) REFERENCES `blood_groups` (`id`),
  CONSTRAINT `blood_requests_ibfk_3` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `conversation_participants`
--
CREATE TABLE `conversation_participants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conversation_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_type` enum('donor','hospital','admin') NOT NULL,
  `joined_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `last_read_at` timestamp NULL DEFAULT NULL,
  `is_muted` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_participant` (`conversation_id`,`user_id`,`user_type`),
  CONSTRAINT `conversation_participants_ibfk_1` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `conversations`
--
CREATE TABLE `conversations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conversation_uuid` varchar(36) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `conversation_type` enum('donor_hospital','hospital_donor','admin_user','support') NOT NULL,
  `participant1_id` int(11) NOT NULL,
  `participant1_type` enum('donor','hospital','admin') NOT NULL,
  `participant2_id` int(11) NOT NULL,
  `participant2_type` enum('donor','hospital','admin') NOT NULL,
  `last_message_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `conversation_uuid` (`conversation_uuid`),
  KEY `idx_participant1` (`participant1_type`,`participant1_id`),
  KEY `idx_participant2` (`participant2_type`,`participant2_id`),
  KEY `idx_last_message` (`last_message_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `daily_stats`
--
CREATE TABLE `daily_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stat_date` date NOT NULL,
  `new_donors` int(11) DEFAULT 0,
  `new_hospitals` int(11) DEFAULT 0,
  `new_requests` int(11) DEFAULT 0,
  `new_donations` int(11) DEFAULT 0,
  `completed_donations` int(11) DEFAULT 0,
  `total_users` int(11) DEFAULT 0,
  `total_hospitals` int(11) DEFAULT 0,
  `pending_requests` int(11) DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `stat_date` (`stat_date`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `daily_stats`
--
INSERT INTO `daily_stats` VALUES ('1', '2026-01-24', '3', '0', '2', '1', '0', '7', '0', '3', '2026-01-24 20:09:39');
INSERT INTO `daily_stats` VALUES ('7', '2026-01-26', '2', '0', '0', '0', '0', '9', '0', '0', '2026-01-26 19:49:23');
INSERT INTO `daily_stats` VALUES ('9', '2026-01-31', '1', '0', '0', '0', '0', '10', '0', '0', '2026-01-31 07:04:11');
INSERT INTO `daily_stats` VALUES ('10', '2026-02-23', '5', '0', '0', '3', '0', '15', '0', '0', '2026-02-23 20:42:06');
INSERT INTO `daily_stats` VALUES ('18', '2026-02-24', '1', '0', '0', '0', '0', '16', '0', '0', '2026-02-24 06:48:24');

--
-- Structure de la table `distance_cache`
--
CREATE TABLE `distance_cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_type` enum('user','hospital') DEFAULT NULL,
  `from_id` int(11) DEFAULT NULL,
  `to_type` enum('user','hospital') DEFAULT NULL,
  `to_id` int(11) DEFAULT NULL,
  `distance_km` decimal(10,2) DEFAULT NULL,
  `calculated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_distance` (`from_type`,`from_id`,`to_type`,`to_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `donation_appointments`
--
CREATE TABLE `donation_appointments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appointment_uuid` varchar(36) NOT NULL,
  `hospital_id` int(11) NOT NULL,
  `donor_id` int(11) NOT NULL,
  `blood_group_id` int(11) NOT NULL,
  `appointment_date` date NOT NULL,
  `appointment_time` time NOT NULL,
  `duration_minutes` int(11) DEFAULT 45,
  `status` enum('scheduled','confirmed','completed','cancelled','no_show') DEFAULT 'scheduled',
  `procedure_id` int(11) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `reminder_sent` tinyint(1) DEFAULT 0,
  `check_in_time` datetime DEFAULT NULL,
  `check_out_time` datetime DEFAULT NULL,
  `actual_duration` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `appointment_uuid` (`appointment_uuid`),
  UNIQUE KEY `unique_appointment` (`hospital_id`,`appointment_date`,`appointment_time`,`donor_id`),
  KEY `blood_group_id` (`blood_group_id`),
  KEY `procedure_id` (`procedure_id`),
  KEY `idx_upcoming_appointments` (`hospital_id`,`appointment_date`,`status`),
  KEY `idx_donor_appointments` (`donor_id`,`appointment_date`),
  CONSTRAINT `donation_appointments_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospitals` (`id`) ON DELETE CASCADE,
  CONSTRAINT `donation_appointments_ibfk_2` FOREIGN KEY (`donor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `donation_appointments_ibfk_3` FOREIGN KEY (`blood_group_id`) REFERENCES `blood_groups` (`id`),
  CONSTRAINT `donation_appointments_ibfk_4` FOREIGN KEY (`procedure_id`) REFERENCES `hospital_procedures` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `donation_requests`
--
CREATE TABLE `donation_requests` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_id` int(11) NOT NULL,
  `blood_group_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `urgency` enum('low','medium','high') DEFAULT 'medium',
  `status` enum('pending','fulfilled','cancelled') DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `fulfilled_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `hospital_id` (`hospital_id`),
  KEY `blood_group_id` (`blood_group_id`),
  CONSTRAINT `donation_requests_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospitals` (`id`) ON DELETE CASCADE,
  CONSTRAINT `donation_requests_ibfk_2` FOREIGN KEY (`blood_group_id`) REFERENCES `blood_groups` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `donation_requests`
--
INSERT INTO `donation_requests` VALUES ('1', '1', '1', '2', 'medium', 'pending', '', '2026-01-24 01:30:27', NULL);
INSERT INTO `donation_requests` VALUES ('2', '1', '3', '1', 'medium', 'fulfilled', 'urgent', '2026-01-24 01:46:11', '2026-01-24 02:04:07');
INSERT INTO `donation_requests` VALUES ('3', '1', '3', '4', 'high', 'pending', 'tres urgent svp', '2026-01-24 02:13:57', NULL);
INSERT INTO `donation_requests` VALUES ('4', '1', '6', '2', 'high', 'fulfilled', 'urgent', '2026-01-24 12:47:23', '2026-01-24 12:50:10');

--
-- Structure de la table `donation_stats`
--
CREATE TABLE `donation_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `total_donations` int(11) DEFAULT 0,
  `consecutive_donations` int(11) DEFAULT 0,
  `last_donation_date` date DEFAULT NULL,
  `helped_hospitals` int(11) DEFAULT 0,
  `urgent_responses` int(11) DEFAULT 0,
  `fast_responses` int(11) DEFAULT 0,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_stats` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `donation_stats`
--
INSERT INTO `donation_stats` VALUES ('1', '8', '0', '0', NULL, '0', '0', '0', '2026-01-24 12:45:13');
INSERT INTO `donation_stats` VALUES ('2', '9', '0', '0', NULL, '0', '0', '0', '2026-01-24 20:09:39');
INSERT INTO `donation_stats` VALUES ('3', '10', '0', '0', NULL, '0', '0', '0', '2026-01-26 19:44:17');
INSERT INTO `donation_stats` VALUES ('4', '11', '0', '0', NULL, '0', '0', '0', '2026-01-26 19:49:23');
INSERT INTO `donation_stats` VALUES ('5', '12', '0', '0', NULL, '0', '0', '0', '2026-01-31 07:04:11');
INSERT INTO `donation_stats` VALUES ('6', '13', '0', '0', NULL, '0', '0', '0', '2026-02-23 13:32:30');
INSERT INTO `donation_stats` VALUES ('7', '14', '0', '0', NULL, '0', '0', '0', '2026-02-23 13:41:18');
INSERT INTO `donation_stats` VALUES ('8', '15', '0', '0', NULL, '0', '0', '0', '2026-02-23 15:52:06');
INSERT INTO `donation_stats` VALUES ('9', '16', '0', '0', NULL, '0', '0', '0', '2026-02-23 19:37:46');
INSERT INTO `donation_stats` VALUES ('10', '17', '0', '0', NULL, '0', '0', '0', '2026-02-23 20:42:06');

--
-- Structure de la table `donations`
--
CREATE TABLE `donations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `donor_id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `donation_date` date DEFAULT NULL,
  `status` enum('scheduled','completed','cancelled') DEFAULT 'scheduled',
  `hospital_confirmed` tinyint(1) DEFAULT 0,
  `admin_confirmed` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `donor_id` (`donor_id`),
  KEY `request_id` (`request_id`),
  CONSTRAINT `donations_ibfk_1` FOREIGN KEY (`donor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `donations_ibfk_2` FOREIGN KEY (`request_id`) REFERENCES `donation_requests` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `donations`
--
INSERT INTO `donations` VALUES ('1', '2', '2', NULL, 'scheduled', '0', '0', '2026-01-24 01:48:02');
INSERT INTO `donations` VALUES ('2', '8', '4', NULL, 'scheduled', '0', '0', '2026-01-24 12:49:01');
INSERT INTO `donations` VALUES ('3', '13', '1', NULL, 'scheduled', '0', '0', '2026-02-23 13:36:31');
INSERT INTO `donations` VALUES ('4', '15', '1', NULL, 'scheduled', '0', '0', '2026-02-23 16:01:20');
INSERT INTO `donations` VALUES ('5', '16', '1', NULL, 'scheduled', '0', '0', '2026-02-23 19:41:51');

--
-- Structure de la table `geocoding_cache`
--
CREATE TABLE `geocoding_cache` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address_hash` varchar(64) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `country` varchar(100) DEFAULT NULL,
  `cached_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `address_hash` (`address_hash`),
  KEY `idx_address_hash` (`address_hash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `hospital_procedures`
--
CREATE TABLE `hospital_procedures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_id` int(11) NOT NULL,
  `procedure_type` enum('donation','distribution','testing','storage') NOT NULL,
  `name` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `duration_minutes` int(11) DEFAULT NULL,
  `requirements` text DEFAULT NULL,
  `instructions` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_hospital_procedures` (`hospital_id`,`procedure_type`,`is_active`),
  CONSTRAINT `hospital_procedures_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospitals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `hospital_reports`
--
CREATE TABLE `hospital_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_id` int(11) NOT NULL,
  `report_type` enum('daily','weekly','monthly','quarterly','yearly','custom') NOT NULL,
  `period_start` date NOT NULL,
  `period_end` date NOT NULL,
  `total_donations` int(11) DEFAULT 0,
  `total_requests` int(11) DEFAULT 0,
  `fulfillment_rate` decimal(5,2) DEFAULT 0.00,
  `average_response_time_hours` decimal(5,2) DEFAULT NULL,
  `critical_alerts` int(11) DEFAULT 0,
  `appointments_scheduled` int(11) DEFAULT 0,
  `appointments_completed` int(11) DEFAULT 0,
  `blood_collected_ml` int(11) DEFAULT 0,
  `blood_used_ml` int(11) DEFAULT 0,
  `blood_expired_ml` int(11) DEFAULT 0,
  `report_data` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`report_data`)),
  `generated_by` int(11) DEFAULT NULL,
  `generated_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_hospital_reports` (`hospital_id`,`report_type`,`period_end`),
  CONSTRAINT `hospital_reports_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospitals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `hospital_stats`
--
CREATE TABLE `hospital_stats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_id` int(11) NOT NULL,
  `total_requests` int(11) DEFAULT 0,
  `fulfilled_requests` int(11) DEFAULT 0,
  `pending_requests` int(11) DEFAULT 0,
  `cancelled_requests` int(11) DEFAULT 0,
  `total_donors_helped` int(11) DEFAULT 0,
  `average_response_time` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `hospital_id` (`hospital_id`),
  CONSTRAINT `hospital_stats_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospitals` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `hospital_stats`
--
INSERT INTO `hospital_stats` VALUES ('1', '3', '0', '0', '0', '0', '0', NULL, '2026-02-23 20:50:30', '2026-02-23 20:50:30');

--
-- Structure de la table `hospital_transfers`
--
CREATE TABLE `hospital_transfers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `transfer_uuid` varchar(36) NOT NULL,
  `from_hospital_id` int(11) NOT NULL,
  `to_hospital_id` int(11) NOT NULL,
  `blood_group_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `transfer_date` date NOT NULL,
  `status` enum('pending','approved','in_transit','delivered','cancelled') DEFAULT 'pending',
  `reason` text DEFAULT NULL,
  `driver_name` varchar(100) DEFAULT NULL,
  `driver_phone` varchar(20) DEFAULT NULL,
  `estimated_arrival` datetime DEFAULT NULL,
  `actual_arrival` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `transfer_uuid` (`transfer_uuid`),
  KEY `from_hospital_id` (`from_hospital_id`),
  KEY `to_hospital_id` (`to_hospital_id`),
  KEY `blood_group_id` (`blood_group_id`),
  KEY `idx_status` (`status`),
  KEY `idx_transfer_date` (`transfer_date`),
  CONSTRAINT `hospital_transfers_ibfk_1` FOREIGN KEY (`from_hospital_id`) REFERENCES `hospitals` (`id`) ON DELETE CASCADE,
  CONSTRAINT `hospital_transfers_ibfk_2` FOREIGN KEY (`to_hospital_id`) REFERENCES `hospitals` (`id`) ON DELETE CASCADE,
  CONSTRAINT `hospital_transfers_ibfk_3` FOREIGN KEY (`blood_group_id`) REFERENCES `blood_groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `hospitals`
--
CREATE TABLE `hospitals` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `hospital_name` varchar(150) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `contact_person` varchar(100) DEFAULT NULL,
  `is_verified` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `hospitals`
--
INSERT INTO `hospitals` VALUES ('1', 'Saintluis@gmail.com', '$2y$10$73wGHeg/xmlBGc6.VlBPUuL1aVn9DlFfO4pnMvsx3OShrxWVKI.Im', 'Saint luis', '+237683616524', 'DOUALA', 'hgdsghdg', 'Dr Russel', '1', '2026-01-24 00:38:22', NULL, NULL);
INSERT INTO `hospitals` VALUES ('2', 'padre@gmail.com', '$2y$10$c0jvYOBkU8dgCh/8zlbq..xzkBORPwP8z2..idR7HfxK1H4n/iJyS', 'Padre Pio', '+237670762128', 'douala', 'akwa', 'Dr Fortune', '0', '2026-02-23 15:57:55', NULL, NULL);
INSERT INTO `hospitals` VALUES ('3', 'contact@hospital.com', '$2y$10$YrD9/.xCIsYfWSmQ.6An5.Zx/PTrx95G5Bx2ldMlM8KzIRJmp6Q5W', 'unite', '+237693651524', 'douala', 'akwa', 'Dr Fortune', '1', '2026-02-23 20:50:30', NULL, NULL);

--
-- Structure de la table `inventory_alerts`
--
CREATE TABLE `inventory_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hospital_id` int(11) NOT NULL,
  `blood_group_id` int(11) NOT NULL,
  `alert_type` enum('critical','low_stock','expiring_soon','excess_stock') NOT NULL,
  `current_quantity` int(11) NOT NULL,
  `threshold_quantity` int(11) NOT NULL,
  `message` text NOT NULL,
  `is_resolved` tinyint(1) DEFAULT 0,
  `resolved_by` int(11) DEFAULT NULL,
  `resolved_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `blood_group_id` (`blood_group_id`),
  KEY `idx_active_alerts` (`hospital_id`,`is_resolved`,`created_at`),
  CONSTRAINT `inventory_alerts_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospitals` (`id`) ON DELETE CASCADE,
  CONSTRAINT `inventory_alerts_ibfk_2` FOREIGN KEY (`blood_group_id`) REFERENCES `blood_groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `level_rewards`
--
CREATE TABLE `level_rewards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` int(11) NOT NULL,
  `reward_type` enum('badge','title','feature','bonus') NOT NULL,
  `reward_value` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_level_reward` (`level`,`reward_type`,`reward_value`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `level_rewards`
--
INSERT INTO `level_rewards` VALUES ('1', '1', 'title', 'Nouveau donneur', 'Votre premier niveau !', '?');
INSERT INTO `level_rewards` VALUES ('2', '5', 'badge', 'rising_star', 'Étoile montante', '⭐');
INSERT INTO `level_rewards` VALUES ('3', '10', 'feature', 'priority_notifications', 'Notifications prioritaires', '?');
INSERT INTO `level_rewards` VALUES ('4', '15', 'badge', 'dedicated_donor', 'Donneur dévoué', '❤️');
INSERT INTO `level_rewards` VALUES ('5', '20', 'bonus', 'xp_boost_1.5x', 'Boost XP 1.5x pendant 7 jours', '?');
INSERT INTO `level_rewards` VALUES ('6', '25', 'title', 'Donneur Expérimenté', 'Un vrai professionnel du don', '?‍⚕️');
INSERT INTO `level_rewards` VALUES ('7', '30', 'badge', 'elite_donor', 'Donneur d\'élite', '?');
INSERT INTO `level_rewards` VALUES ('8', '40', 'feature', 'custom_profile', 'Profil personnalisé', '?');
INSERT INTO `level_rewards` VALUES ('9', '50', 'title', 'Légende du Don', 'Vous êtes une légende vivante', '?');

--
-- Structure de la table `messages`
--
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `conversation_id` int(11) NOT NULL,
  `sender_id` int(11) NOT NULL,
  `sender_type` enum('donor','hospital','admin') NOT NULL,
  `message` text NOT NULL,
  `message_type` enum('text','image','file','system') DEFAULT 'text',
  `file_path` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `read_at` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_conversation` (`conversation_id`,`created_at`),
  KEY `idx_unread` (`conversation_id`,`is_read`,`sender_id`,`sender_type`),
  CONSTRAINT `messages_ibfk_1` FOREIGN KEY (`conversation_id`) REFERENCES `conversations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `notification_preferences`
--
CREATE TABLE `notification_preferences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_type` enum('donor','hospital','admin') NOT NULL,
  `email_notifications` tinyint(1) DEFAULT 1,
  `push_notifications` tinyint(1) DEFAULT 1,
  `new_request_notify` tinyint(1) DEFAULT 1,
  `response_notify` tinyint(1) DEFAULT 1,
  `urgent_notify` tinyint(1) DEFAULT 1,
  `system_notify` tinyint(1) DEFAULT 1,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_prefs` (`user_id`,`user_type`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `notification_preferences`
--
INSERT INTO `notification_preferences` VALUES ('1', '2', 'donor', '1', '1', '1', '1', '1', '1', '2026-01-24 01:51:15');
INSERT INTO `notification_preferences` VALUES ('2', '4', 'admin', '1', '1', '1', '1', '1', '1', '2026-01-24 01:51:15');
INSERT INTO `notification_preferences` VALUES ('3', '5', 'donor', '1', '1', '1', '1', '1', '1', '2026-01-24 01:51:15');
INSERT INTO `notification_preferences` VALUES ('4', '6', 'donor', '1', '1', '1', '1', '1', '1', '2026-01-24 01:51:15');
INSERT INTO `notification_preferences` VALUES ('8', '1', 'hospital', '1', '1', '1', '1', '1', '1', '2026-01-24 01:51:15');

--
-- Structure de la table `notifications`
--
CREATE TABLE `notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `user_type` enum('donor','hospital','admin') NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','success','warning','danger','urgent') DEFAULT 'info',
  `icon` varchar(50) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_user_notifications` (`user_id`,`user_type`,`is_read`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `password_resets`
--
CREATE TABLE `password_resets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `token` varchar(255) NOT NULL,
  `user_type` enum('donor','hospital','admin') NOT NULL,
  `expires_at` datetime NOT NULL,
  `used` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_token` (`token`),
  KEY `idx_email` (`email`),
  KEY `idx_expires` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `prediction_models`
--
CREATE TABLE `prediction_models` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `model_name` varchar(100) NOT NULL,
  `hospital_id` int(11) DEFAULT NULL,
  `blood_group_id` int(11) DEFAULT NULL,
  `model_type` enum('demand','inventory','donor_behavior') NOT NULL,
  `accuracy` decimal(5,4) DEFAULT NULL,
  `features` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`features`)),
  `model_data` longblob DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `last_trained` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `hospital_id` (`hospital_id`),
  KEY `blood_group_id` (`blood_group_id`),
  KEY `idx_active_models` (`is_active`,`model_type`),
  CONSTRAINT `prediction_models_ibfk_1` FOREIGN KEY (`hospital_id`) REFERENCES `hospitals` (`id`) ON DELETE CASCADE,
  CONSTRAINT `prediction_models_ibfk_2` FOREIGN KEY (`blood_group_id`) REFERENCES `blood_groups` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `sessions`
--
CREATE TABLE `sessions` (
  `session_id` varchar(128) NOT NULL,
  `session_data` text DEFAULT NULL,
  `session_expires` int(11) DEFAULT NULL,
  PRIMARY KEY (`session_id`),
  KEY `idx_expires` (`session_expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `shared_files`
--
CREATE TABLE `shared_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `message_id` int(11) NOT NULL,
  `original_filename` varchar(255) NOT NULL,
  `stored_filename` varchar(255) NOT NULL,
  `file_type` varchar(100) DEFAULT NULL,
  `file_size` int(11) DEFAULT NULL,
  `download_count` int(11) DEFAULT 0,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `message_id` (`message_id`),
  CONSTRAINT `shared_files_ibfk_1` FOREIGN KEY (`message_id`) REFERENCES `messages` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `special_events`
--
CREATE TABLE `special_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_code` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `badge_id` int(11) DEFAULT NULL,
  `xp_multiplier` decimal(3,2) DEFAULT 1.00,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `event_code` (`event_code`),
  KEY `badge_id` (`badge_id`),
  CONSTRAINT `special_events_ibfk_1` FOREIGN KEY (`badge_id`) REFERENCES `badges` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `system_alerts`
--
CREATE TABLE `system_alerts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `alert_type` enum('warning','danger','info','success') NOT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `priority` int(11) DEFAULT 1,
  `is_active` tinyint(1) DEFAULT 1,
  `affected_entity` varchar(50) DEFAULT NULL,
  `action_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `resolved_at` datetime DEFAULT NULL,
  `resolved_by` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `resolved_by` (`resolved_by`),
  CONSTRAINT `system_alerts_ibfk_1` FOREIGN KEY (`resolved_by`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Structure de la table `user_badges`
--
CREATE TABLE `user_badges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `badge_id` int(11) NOT NULL,
  `earned_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `progress` int(11) DEFAULT 100,
  `is_equipped` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_badge` (`user_id`,`badge_id`),
  KEY `badge_id` (`badge_id`),
  KEY `idx_user_badges` (`user_id`,`earned_at`),
  CONSTRAINT `user_badges_ibfk_1` FOREIGN KEY (`badge_id`) REFERENCES `badges` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `user_badges`
--
INSERT INTO `user_badges` VALUES ('1', '8', '1', '2026-01-24 12:45:13', '100', '0');
INSERT INTO `user_badges` VALUES ('2', '9', '1', '2026-01-24 20:09:39', '100', '0');
INSERT INTO `user_badges` VALUES ('3', '10', '1', '2026-01-26 19:44:17', '100', '0');
INSERT INTO `user_badges` VALUES ('4', '11', '1', '2026-01-26 19:49:23', '100', '0');
INSERT INTO `user_badges` VALUES ('5', '12', '1', '2026-01-31 07:04:11', '100', '0');
INSERT INTO `user_badges` VALUES ('6', '13', '1', '2026-02-23 13:32:30', '100', '0');
INSERT INTO `user_badges` VALUES ('7', '14', '1', '2026-02-23 13:41:18', '100', '0');
INSERT INTO `user_badges` VALUES ('8', '15', '1', '2026-02-23 15:52:06', '100', '0');
INSERT INTO `user_badges` VALUES ('9', '16', '1', '2026-02-23 19:37:46', '100', '0');
INSERT INTO `user_badges` VALUES ('10', '17', '1', '2026-02-23 20:42:06', '100', '0');

--
-- Structure de la table `user_xp`
--
CREATE TABLE `user_xp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `current_xp` int(11) DEFAULT 0,
  `total_xp` int(11) DEFAULT 0,
  `level` int(11) DEFAULT 1,
  `level_title` varchar(50) DEFAULT 'Nouveau donneur',
  `next_level_xp` int(11) DEFAULT 100,
  `last_level_up` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `user_xp`
--
INSERT INTO `user_xp` VALUES ('1', '8', '0', '0', '1', 'Nouveau donneur', '100', NULL, '2026-01-24 12:45:13', '2026-01-24 12:45:13');
INSERT INTO `user_xp` VALUES ('2', '9', '0', '0', '1', 'Nouveau donneur', '100', NULL, '2026-01-24 20:09:39', '2026-01-24 20:09:39');
INSERT INTO `user_xp` VALUES ('3', '10', '0', '0', '1', 'Nouveau donneur', '100', NULL, '2026-01-26 19:44:17', '2026-01-26 19:44:17');
INSERT INTO `user_xp` VALUES ('4', '11', '0', '0', '1', 'Nouveau donneur', '100', NULL, '2026-01-26 19:49:23', '2026-01-26 19:49:23');
INSERT INTO `user_xp` VALUES ('5', '12', '0', '0', '1', 'Nouveau donneur', '100', NULL, '2026-01-31 07:04:11', '2026-01-31 07:04:11');
INSERT INTO `user_xp` VALUES ('6', '13', '0', '0', '1', 'Nouveau donneur', '100', NULL, '2026-02-23 13:32:30', '2026-02-23 13:32:30');
INSERT INTO `user_xp` VALUES ('7', '14', '0', '0', '1', 'Nouveau donneur', '100', NULL, '2026-02-23 13:41:18', '2026-02-23 13:41:18');
INSERT INTO `user_xp` VALUES ('8', '15', '0', '0', '1', 'Nouveau donneur', '100', NULL, '2026-02-23 15:52:06', '2026-02-23 15:52:06');
INSERT INTO `user_xp` VALUES ('9', '16', '0', '0', '1', 'New Donor', '100', NULL, '2026-02-23 19:37:46', '2026-02-23 19:37:46');
INSERT INTO `user_xp` VALUES ('10', '17', '0', '0', '1', 'New Donor', '100', NULL, '2026-02-23 20:42:06', '2026-02-23 20:42:06');

--
-- Structure de la table `users`
--
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `blood_group_id` int(11) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `user_type` enum('donor','admin') DEFAULT 'donor',
  `is_verified` tinyint(1) DEFAULT 0,
  `can_donate` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `latitude` decimal(10,8) DEFAULT NULL,
  `longitude` decimal(11,8) DEFAULT NULL,
  `blood_type` varchar(3) DEFAULT NULL,
  `last_donation` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `blood_group_id` (`blood_group_id`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`blood_group_id`) REFERENCES `blood_groups` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Données de la table `users`
--
INSERT INTO `users` VALUES ('2', 'yvan@gmail.com', '$2y$10$iocXVzfmoG4WgqCAdVubC.88LIGS4crHuNdu0a/ypnbZBato6EPoW', 'DIFFO', '3', '+237683616524', 'DOUALA', 'BONABERI', 'donor', '1', '1', '2026-01-23 23:55:41', NULL, NULL, NULL, NULL);
INSERT INTO `users` VALUES ('4', 'admin@bloodlink.com', '$2y$10$h/bTee5Dyae/AuqqXZSTHeT7q5So26cng6VG39xvrMkkmtESsyddW', 'Administrateur Principal', NULL, NULL, NULL, NULL, 'admin', '1', '0', '2026-01-24 00:11:49', NULL, NULL, NULL, NULL);
INSERT INTO `users` VALUES ('5', 'kinton@gmail.com', '$2y$10$6khhZrXOrIeOlI9I5Xnub.kDv0VFsUhUxJfbchg6Lo.kiqsggC2tq', 'KINTON', '5', '+237683616524', 'ouest', 'Bonaberi', 'donor', '1', '1', '2026-01-24 00:26:49', NULL, NULL, NULL, NULL);
INSERT INTO `users` VALUES ('6', 'leonel@gmail.com', '$2y$10$ojGpGn/UBbjA4JX/tol8bexc9ldgGNtYoUwIzxgNeOUepfyklIL/u', 'Leonel', '7', '+237683616524', 'BAMENDA', '', 'donor', '1', '1', '2026-01-24 00:48:17', NULL, NULL, NULL, NULL);
INSERT INTO `users` VALUES ('7', 'glory@gmail.com', '$2y$10$O1DIo1F1uGtVlaOfffFGzuUC2iML5KQjbIg4DPrCrf1KLFkcd7L7.', 'Glory', '1', '+237683616524', 'BAMENDA', 'douala', 'donor', '1', '1', '2026-01-24 02:30:47', NULL, NULL, NULL, NULL);
INSERT INTO `users` VALUES ('8', 'fortune@gmail.com', '$2y$10$.o7egj9Cv4./Rtvy/Io5Ren1gAGy1u2l0Ls8ouxds5wcDM/pGxFi2', 'tchakounte', '6', '+237670762128', 'douala', 'akwa', 'donor', '1', '1', '2026-01-24 12:45:13', NULL, NULL, NULL, NULL);
INSERT INTO `users` VALUES ('9', 'hopitalgeneral@gmail.com', '$2y$10$/.rP/888Unt.wq.AAwjSx.QNmf.AWWJhmWC/IKb5S45P/BzHofB.S', 'fortune', '1', '+237670762128', 'douala', 'akwa', 'donor', '1', '1', '2026-01-24 20:09:39', NULL, NULL, NULL, NULL);
INSERT INTO `users` VALUES ('10', 'fosto@gmail.com', '$2y$10$IhmCpqNZ3jaxQABL2BsjXOoxt5eSgv9W7iIeXV3IPy/Zx3KKgj0qO', 'fosto', '6', '670762128', 'douala', 'vallee conquete', 'donor', '1', '1', '2026-01-26 19:44:17', NULL, NULL, NULL, NULL);
INSERT INTO `users` VALUES ('11', 'laquintiny@gmail.com', '$2y$10$0PKOYz2eTttGlmFURcbN.OCn9OUK.CQwCGUEv4uiODOFXi4Ctpeoa', 'la quintiny', '8', '+237670762128', 'douala', 'akwa', 'donor', '1', '1', '2026-01-26 19:49:23', NULL, NULL, NULL, NULL);
INSERT INTO `users` VALUES ('12', 'generak@gmail.com', '$2y$10$7YTNb0i8I1MoLbCl.wZ1keJbH8YvSf2hrcHD6TlaIkdEgoTPwLVkq', 'fortune', '5', '670762128', 'DOUALA', 'logpom', 'donor', '1', '1', '2026-01-31 07:04:11', NULL, NULL, NULL, NULL);
INSERT INTO `users` VALUES ('13', 'leonel42@gmail.com', '$2y$10$3B5vjU7okzewoiEXDYVflO5JrXbH7aaw4QLzTtrhvdObhQeO7mw8G', 'Leonel', '1', '683616524', 'Mbouda', '', 'donor', '1', '1', '2026-02-23 13:32:30', NULL, NULL, NULL, NULL);
INSERT INTO `users` VALUES ('14', 'hopital@gmail.com', '$2y$10$wsiCdrVrMrVdL8RCS/hBH.OB.Watqt5OfqrOKu8giELJ2aM4EkKhG', 'Hopital des Soeurs', '7', '+237658208126', 'Yaounde', 'Logpom', 'donor', '1', '1', '2026-02-23 13:41:18', NULL, NULL, NULL, NULL);
INSERT INTO `users` VALUES ('15', 'brenda@gmail.com', '$2y$10$dtPydVRp8BKU8zRQzkv6qujlzGL/.QjpEkaASIzAjQSCZTLsMtR5O', 'Brenda', '3', '+237693651524', 'douala', 'akwa', 'donor', '1', '1', '2026-02-23 15:52:06', NULL, NULL, NULL, NULL);
INSERT INTO `users` VALUES ('16', 'terpil@gmail.com', '$2y$10$oDqUmgfKf7Hqmx9slFNx7.ynhKQ.I0TlsVtDfV5r6FXDnOxtCHl2m', 'Trepil', '1', '+2376524314', 'douala', 'akwa', 'donor', '1', '1', '2026-02-23 19:37:46', NULL, NULL, NULL, NULL);
INSERT INTO `users` VALUES ('17', 'gill@gmail.com', '$2y$10$N7GX1RunNXZ16Jp.YPEXQO9jg1h5x/YDwlhF0ye7AcXtatBhJviB6', 'GILL', '8', '+237670762128', 'douala', 'akwa', 'donor', '1', '1', '2026-02-23 20:42:06', NULL, NULL, NULL, NULL);
INSERT INTO `users` VALUES ('18', 'diffo@gmail.com', '$2y$10$dnWQXmgO4GCv9jLNiUxuoeTL4j0uElvh3UajjEgjRBNkLJNg9feo6', 'DIFFO YVAN', NULL, NULL, NULL, NULL, 'admin', '1', '1', '2026-02-24 06:48:24', NULL, NULL, NULL, NULL);

